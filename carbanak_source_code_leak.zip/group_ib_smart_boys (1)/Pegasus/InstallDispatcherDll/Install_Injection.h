/*
	Install_Injection.h
*/

#include <Windows.h>

#include "..\Shellcode\shellcode.h"

BOOL instInjection(SHELLCODE_CONTEXT *pSContext);