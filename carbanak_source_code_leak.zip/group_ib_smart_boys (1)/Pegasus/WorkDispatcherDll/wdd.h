/*
	wdd.h
*/

#pragma once

#include <windows.h>











