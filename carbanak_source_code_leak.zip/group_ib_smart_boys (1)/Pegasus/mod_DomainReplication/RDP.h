/*
	RDP.h
*/

#include <Windows.h>

BOOL rdpAttemptReplication(LPWSTR wszTargetMachine, LPWSTR wszUsername, LPWSTR wszPassword);