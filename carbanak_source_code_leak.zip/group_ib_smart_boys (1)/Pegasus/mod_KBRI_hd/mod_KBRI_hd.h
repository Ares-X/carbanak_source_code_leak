/*
	mod_KBRI_hd.h
*/

#pragma once

#include <windows.h>











