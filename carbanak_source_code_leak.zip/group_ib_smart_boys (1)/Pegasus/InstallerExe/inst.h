/*
	inst.h
	Headers for main file
*/

#pragma once

#include <windows.h>







