/*
	kbriController.h
*/

#include <Windows.h>

#include "KBRI.h"

BOOL kcStartController(KBRI_GLOBALS *KBRI);