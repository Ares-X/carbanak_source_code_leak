/*
	kbriGeneratePurpose.h
*/

#include <Windows.h>

BOOL kgpGeneratePurpose(LPSTR *pszResult, UINT64 i64Sum);