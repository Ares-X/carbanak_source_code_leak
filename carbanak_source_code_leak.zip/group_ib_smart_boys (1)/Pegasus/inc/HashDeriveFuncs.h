/*
	HashDeriveFuncs.h
*/

#pragma once

#include <windows.h>

UINT64 i64CalcTargetMachineHash(LPWSTR wszTargetMachineName);