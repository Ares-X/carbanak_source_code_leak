/*
	SecureClean.h
	Headers
*/

#include <windows.h>


BOOL scSecureDeleteFile(LPWSTR wszFilename);