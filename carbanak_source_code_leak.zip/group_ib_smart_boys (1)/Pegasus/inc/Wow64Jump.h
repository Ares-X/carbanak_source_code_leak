/*
	Wow64Jump.h
*/

#pragma once

#include <Windows.h>

VOID wjWow64JumpTo64();