/*

	machineid.h
	
*/

#pragma once

#include <windows.h>

UINT64 i64MakeMachineID();


