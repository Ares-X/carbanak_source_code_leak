<?php
/*
	config.php
*/

$g_db = array(
	'host' 		=> 'localhost',
	'db' 		=> 'pegasus',
	'user' 		=> 'root',
	'password' 	=> '12345'
);

// TARGET_BUILDCHAIN_HASH
$g_k = '7393c9a643eb4a76';   




?>